import { initializeApp } from "./firebase-app.js";
import { getFirestore, doc, setDoc, onSnapshot } from "./firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBSKtg7y1C3bLGyojiI-6hCdU-UOCYrMYY",
  authDomain: "web-doubbletech.firebaseapp.com",
  projectId: "web-doubbletech",
  storageBucket: "web-doubbletech.firebasestorage.app",
  messagingSenderId: "629547474346",
  appId: "1:629547474346:web:d788f9876601e8fc545fd3",
  measurementId: "G-3VEKHEH99Q"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

async function init() {
    const data = await chrome.storage.local.get(['isAuthorized', 'userPhone']);
    const viewActivation = document.getElementById('view-activation');
    const viewMain = document.getElementById('view-main');

    if (data.isAuthorized) {
        viewMain.classList.add('active');
        setupLiveListener(data.userPhone);
    } else {
        viewActivation.classList.add('active');
    }
}

// Listen for Admin approval in real-time
function setupLiveListener(phone) {
    const userRef = doc(db, "artifacts", "doubbletech-secure-web", "public", "data", "users", "user_" + phone);
    onSnapshot(userRef, (docSnap) => {
        if (docSnap.exists() && docSnap.data().status === 'Pending') {
            chrome.storage.local.set({ isAuthorized: false });
            location.reload();
        }
    });
}

document.getElementById('activateBtn')?.addEventListener('click', async () => {
    const phone = document.getElementById('phoneInput').value.trim();
    const msg = document.getElementById('msg');
    if (!phone) return;

    msg.innerText = "Connecting to Doubble Tech Cloud...";

    try {
        const userRef = doc(db, "artifacts", "doubbletech-secure-web", "public", "data", "users", "user_" + phone);
        await setDoc(userRef, {
            phone: phone,
            status: "Pending",
            timestamp: Date.now()
        }, { merge: true });

        // For this version, we save locally so they see the portal immediately if approved later
        await chrome.storage.local.set({ isAuthorized: true, userPhone: phone });
        location.reload();
    } catch (e) {
        msg.innerText = "Error: Check internet connection.";
    }
});

document.getElementById('urlInput')?.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        let url = e.target.value.trim();
        if (!url.startsWith('http')) url = 'https://' + url;
        chrome.tabs.create({ url: url });
        window.close();
    }
});

init();