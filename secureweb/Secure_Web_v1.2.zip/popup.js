import { initializeApp } from "./firebase-app.js";
import { getFirestore, doc, setDoc, onSnapshot } from "./firebase-firestore.js";

// YOUR UNIQUE KEYS FROM THE SCREENSHOT
const firebaseConfig = {
  apiKey: "AIzaSyBSKtg7y1C3bLGyojiI-6hCdU-UOCYrMYY",
  authDomain: "web-doubbletech.firebaseapp.com",
  projectId: "web-doubbletech",
  storageBucket: "web-doubbletech.firebasestorage.app",
  messagingSenderId: "629547474346",
  appId: "1:629547474346:web:d788f9876601e8fc545fd3",
  measurementId: "G-3VEKHEH99Q"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

async function init() {
    const data = await chrome.storage.local.get(['isAuthorized', 'userPhone']);
    if (data.isAuthorized) {
        document.getElementById('view-main').classList.add('active');
        // Auto-sync IP/Machine ID here
    } else {
        document.getElementById('view-activation').classList.add('active');
    }
}

document.getElementById('activateBtn').addEventListener('click', async () => {
    const phone = document.getElementById('phoneInput').value;
    if (!phone) return;
    
    // Logic to send "Pending" status to your Firebase Dashboard
    const userRef = doc(db, "artifacts", "doubbletech-secure-web", "public", "data", "users", "user_"+phone);
    await setDoc(userRef, {
        phone: phone,
        status: "Pending",
        timestamp: Date.now()
    }, { merge: true });

    document.getElementById('msg').innerText = "Request Sent! Wait for Admin Approval.";
});

// Launch URL logic
document.getElementById('urlInput')?.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        let url = e.target.value.trim();
        if (!url.startsWith('http')) url = 'https://' + url;
        chrome.tabs.create({ url: url });
        window.close();
    }
});

init();