import { initializeApp } from "./firebase-app.js";
import { getFirestore, doc, setDoc } from "./firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBSKtg7y1C3bLGyojiI-6hCdU-UOCYrMYY",
  authDomain: "web-doubbletech.firebaseapp.com",
  projectId: "web-doubbletech",
  storageBucket: "web-doubbletech.firebasestorage.app",
  messagingSenderId: "629547474346",
  appId: "1:629547474346:web:d788f9876601e8fc545fd3",
  measurementId: "G-3VEKHEH99Q"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Check login status on open
chrome.storage.local.get(['isAuthorized'], (result) => {
    if (result.isAuthorized) {
        document.getElementById('view-main').classList.add('active');
    } else {
        document.getElementById('view-activation').classList.add('active');
    }
});

// Activation Button Logic
document.getElementById('activateBtn').addEventListener('click', async () => {
    const phone = document.getElementById('phoneInput').value.trim();
    const msg = document.getElementById('msg');
    
    if (!phone) {
        msg.innerText = "Please enter a phone number.";
        return;
    }

    msg.innerText = "Connecting...";

    try {
        const userRef = doc(db, "artifacts", "doubbletech-secure-web", "public", "data", "users", "user_" + phone);
        await setDoc(userRef, {
            phone: phone,
            status: "Pending",
            timestamp: Date.now()
        }, { merge: true });

        // Save status and switch view
        chrome.storage.local.set({ isAuthorized: true, userPhone: phone }, () => {
            location.reload();
        });
    } catch (e) {
        console.error(e);
        msg.innerText = "Connection failed. Check internet.";
    }
});

// Search Logic
document.getElementById('urlInput').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        let url = e.target.value.trim();
        if (!url.startsWith('http')) url = 'https://' + url;
        chrome.tabs.create({ url: url });
        window.close();
    }
});