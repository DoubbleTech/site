chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
    chrome.browsingData.remove({
        "since": (new Date()).getTime() - (1000 * 60 * 60)
    }, {
        "appcache": true, "cache": true, "cookies": true, "history": true, "localStorage": true
    });
});